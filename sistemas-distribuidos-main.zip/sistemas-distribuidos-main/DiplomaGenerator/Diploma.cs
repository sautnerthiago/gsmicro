﻿public class Diploma
{
    public int Id { get; set; }
    public string NomeAluno { get; set; }
    public string Curso { get; set; }
    public DateTime DataConclusao { get; set; }
    public DateTime DataEmissao { get; set; }
}
